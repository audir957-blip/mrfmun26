# Security notes - MRF MUN site

## What is built in
- **Admin login**: password is compared in constant time; 5 wrong tries lock that network out for 15 minutes; the session lasts 8 hours and lives in an HttpOnly, SameSite=Strict cookie (Secure on HTTPS). There is a **Log out** button on the dashboard.
- **Rate limits**: 120 requests/minute per visitor on the API, and 25 registration attempts per 15 minutes per network (a whole school sharing one internet connection can still register).
- **Spam trap**: a hidden form field that real visitors never fill; bots that do are silently ignored.
- **Input checks**: every field is length-limited and cleaned; date of birth, gender, Yes/No, committee and country must be valid options; only plain JSON is accepted, max 20 KB.
- **Browser protections**: Content-Security-Policy (only this site's own scripts run), no framing (clickjacking), no MIME sniffing, strict referrer and permissions policies, HSTS on HTTPS.
- **Data safety**: only the `public` folder is served - `mun.db`, `config.json` and `server.js` cannot be downloaded. SQL uses prepared statements. The CSV export neutralises spreadsheet formulas. Errors never show internal details.
- **Admin page** is not indexed by search engines and is never cached.

## What you must do when going live
1. **Use HTTPS** (most hosts give it free). Then set `NODE_ENV=production` (adds Secure cookies + HSTS). Set `FORCE_HTTPS=1` to redirect http to https.
2. If the host puts a proxy in front (Render, Railway, Cloudflare, nginx...), set `TRUST_PROXY=1` so rate limits see each visitor's real IP.
3. Choose a **long random ADMIN_PASSWORD** (12+ characters). The server refuses the example password and warns about weak ones. Never share it in chat or commit it.
4. **Back up `mun.db`** regularly (it holds students' personal data) and keep it private. Delete old data after the event.
5. Run `npm audit` now and then, and `npm update` before the event to get security fixes.
