# MRF MUN Registration Website

## Media
The logo is `public/assets/logo.png` and the background photos are `public/assets/bg1.jpg` and `public/assets/bg2.jpg` (slow cross-fade slideshow). Replace either file to change them.

## Run locally
1. Install Node.js 18+.
2. `npm install`
3. Set the admin password, then start:
   - Mac/Linux: `ADMIN_PASSWORD="your-long-password" npm start`
   - Windows (PowerShell): `$env:ADMIN_PASSWORD="your-long-password"; npm start`
4. Open http://localhost:3000 (students) and http://localhost:3000/admin.html (organizers).

## Edit content
Committees, countries, dates, venue, fee, eligibility and contact are in `config.json` (placeholders for now). Restart after editing.

## Deploy
Use a host that runs Node and keeps a disk (Render, Railway, Fly.io, or a VPS).
- Build: `npm install`, Start: `npm start`
- Set env vars `ADMIN_PASSWORD` and `NODE_ENV=production`; serve over HTTPS.
- Attach a persistent disk so `mun.db` survives restarts, and back it up regularly.
- Admin login sessions are kept in memory, so organizers log in again after a restart.


### Committee emblems
The six committee emblem PNGs are stored in `public/assets/committees/` and displayed in the Committees section. For full registration functionality, run the site with the Node.js server (`npm install`, then `npm start`) rather than opening `index.html` directly. The committee cards also have a local fallback so their images and descriptions can appear if the config API is unavailable.
