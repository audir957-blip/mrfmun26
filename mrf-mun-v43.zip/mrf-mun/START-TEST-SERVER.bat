@echo off
title MRF MUN - Test Server
cd /d "%~dp0"

echo ============================================
echo   MRF MUN - start site for other devices
echo ============================================
echo.

where node >nul 2>nul || (echo Node.js is not installed. Install Node 22 or newer from nodejs.org, then run this again. & pause & exit /b)

set /p ADMIN_PASSWORD=Choose an admin password (12+ characters, not "password"): 
if "%ADMIN_PASSWORD%"=="" (echo Password cannot be empty. & pause & exit /b)

if not exist node_modules (
  echo Installing packages, please wait...
  call npm.cmd install
)

REM Allow other devices through Windows Firewall (needs "Run as administrator" the first time)
netsh advfirewall firewall show rule name="MRF MUN 3000" >nul 2>nul
if errorlevel 1 (
  netsh advfirewall firewall add rule name="MRF MUN 3000" dir=in action=allow protocol=TCP localport=3000 >nul 2>nul
  if errorlevel 1 (
    echo.
    echo [!] Could not open the firewall. Close this window, right-click this file,
    echo     choose "Run as administrator", and start again. ^(Only needed once.^)
    echo.
  )
)

echo.
echo ----- Open one of these on a phone/laptop connected to the SAME Wi-Fi -----
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do echo   http://%%a:3000
echo.
echo Admin page: add /admin.html to the end of the address.
echo KEEP THIS WINDOW OPEN. Closing it stops the site.
echo ---------------------------------------------------------------------------
echo.
call npm.cmd start
pause
