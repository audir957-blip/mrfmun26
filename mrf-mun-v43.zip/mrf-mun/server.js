// MRF MUN backend: Express + SQLite (built-in node:sqlite).
// Run: npm install && ADMIN_PASSWORD="..." npm start
const express = require('express');
const { DatabaseSync: Database } = require('node:sqlite');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const config = require('./config.json');

const PROD = process.env.NODE_ENV === 'production';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
if (ADMIN_PASSWORD.length < 8) {
  console.error('Set ADMIN_PASSWORD (8+ characters) before starting.'); process.exit(1);
}
if (ADMIN_PASSWORD === 'change-this-long-password') {
  console.error('ADMIN_PASSWORD is still the example value. Choose your own password.'); process.exit(1);
}
if (ADMIN_PASSWORD.length < 12 || /password|12345|qwerty|admin/i.test(ADMIN_PASSWORD)) {
  console.warn('WARNING: ADMIN_PASSWORD looks weak. Use 12+ random characters before going live.');
}

const DB_FILE = process.env.DB_PATH || path.join(__dirname, 'mun.db');   // set DB_PATH to a persistent disk (e.g. /var/data/mun.db) when hosting
try { fs.mkdirSync(path.dirname(DB_FILE), { recursive: true }); } catch { /* ignore */ }
const db = new Database(DB_FILE);
try { fs.chmodSync(DB_FILE, 0o600); } catch { /* not supported on some systems (e.g. Windows) */ }
db.exec(`CREATE TABLE IF NOT EXISTS registrations (
  id TEXT PRIMARY KEY, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  full_name TEXT, guardian TEXT, dob TEXT, gender TEXT, email TEXT UNIQUE, phone TEXT, whatsapp TEXT,
  institution TEXT, grade TEXT, student_id TEXT, committee TEXT, country TEXT,
  experienced TEXT, experience TEXT, reason TEXT, dietary TEXT, emergency_name TEXT, emergency_phone TEXT, cnic TEXT, screenshot_data TEXT, screenshot_mime TEXT, registration_status TEXT DEFAULT 'Pending review', review_message TEXT)`);

for (const [name, type] of [['cnic','TEXT'],['screenshot_data','TEXT'],['screenshot_mime','TEXT'],['registration_status',"TEXT DEFAULT 'Pending review'"],['review_message','TEXT']]) { try { db.exec(`ALTER TABLE registrations ADD COLUMN ${name} ${type}`); } catch (e) { if (!String(e.message).includes('duplicate column')) throw e; } }
db.exec(`CREATE TABLE IF NOT EXISTS observer_registrations (id TEXT PRIMARY KEY, created_at TEXT DEFAULT CURRENT_TIMESTAMP, full_name TEXT NOT NULL, email TEXT NOT NULL, institution TEXT NOT NULL, phone TEXT NOT NULL, interest TEXT NOT NULL, payment_method TEXT NOT NULL, transaction_details TEXT, screenshot_data TEXT, screenshot_mime TEXT, payment_status TEXT DEFAULT 'Pending verification', registration_status TEXT DEFAULT 'Pending review', review_message TEXT)`);
for (const [name, type] of [['screenshot_data','TEXT'],['screenshot_mime','TEXT'],['payment_status',"TEXT DEFAULT 'Pending verification'"],['registration_status',"TEXT DEFAULT 'Pending review'"],['review_message','TEXT']]) { try { db.exec(`ALTER TABLE observer_registrations ADD COLUMN ${name} ${type}`); } catch (e) { if (!String(e.message).includes('duplicate column')) throw e; } }
// Serial numbers for the confirmation message: one shared sequence for delegates and observers, starting at 400.
for (const t of ['registrations', 'observer_registrations']) { try { db.exec(`ALTER TABLE ${t} ADD COLUMN serial INTEGER`); } catch (e) { if (!String(e.message).includes('duplicate column')) throw e; } }
function assignSerial(table, id) {
  const m = t => db.prepare(`SELECT COALESCE(MAX(serial),0) AS m FROM ${t}`).get().m;
  const serial = Math.max(399, m('registrations'), m('observer_registrations')) + 1;
  db.prepare(`UPDATE ${table} SET serial=? WHERE id=?`).run(serial, id);
  return serial;
}

// Optional Ambassador Referral Code (added to existing databases automatically)
for (const t of ['registrations', 'observer_registrations']) { try { db.exec(`ALTER TABLE ${t} ADD COLUMN ambassador_code TEXT`); } catch (e) { if (!String(e.message).includes('duplicate column')) throw e; } }

// Member number shown after approval: Delegate No. (DEL-000, DEL-001 ...) or Observer No. (OBS-000, OBS-001 ...).
// Each list is numbered separately, starting from 0. Numbers are given only when an admin accepts a registration.
for (const t of ['registrations', 'observer_registrations']) { try { db.exec(`ALTER TABLE ${t} ADD COLUMN tracking_id TEXT`); } catch (e) { if (!String(e.message).includes('duplicate column')) throw e; } }
const NUM_PREFIX = { registrations: 'DEL', observer_registrations: 'OBS' };
const NUM_LABEL = { registrations: 'Delegate No.', observer_registrations: 'Observer No.' };
function nextNumber(table) {
  const p = NUM_PREFIX[table];
  let max = -1;
  for (const r of db.prepare(`SELECT tracking_id FROM ${table} WHERE tracking_id LIKE ?`).all(p + '-%')) {
    const n = parseInt(r.tracking_id.slice(p.length + 1), 10); if (n > max) max = n;
  }
  return `${p}-${String(max + 1).padStart(3, '0')}`;
}
// Earlier random TRK- IDs are cleared; accepted registrations then get their number in the order they were accepted.
for (const t of ['registrations', 'observer_registrations']) {
  db.prepare(`UPDATE ${t} SET tracking_id=NULL WHERE tracking_id IS NOT NULL AND tracking_id NOT LIKE ?`).run(NUM_PREFIX[t] + '-%');
  for (const r of db.prepare(`SELECT id FROM ${t} WHERE registration_status='Accepted' AND tracking_id IS NULL ORDER BY created_at, rowid`).all()) {
    db.prepare(`UPDATE ${t} SET tracking_id=? WHERE id=?`).run(nextNumber(t), r.id);
  }
}

// Payment columns (added to existing databases automatically)
for (const [table, cols] of [['registrations', ['payment_method','transaction_details','fee_plan','amount']], ['observer_registrations', ['fee_plan','amount']]]) {
  for (const name of cols) { try { db.exec(`ALTER TABLE ${table} ADD COLUMN ${name} TEXT`); } catch (e) { if (!String(e.message).includes('duplicate column')) throw e; } }
}

const app = express();
app.disable('x-powered-by');
if (process.env.TRUST_PROXY) {            // set TRUST_PROXY=1 when hosted behind a proxy/CDN (needed for correct client IPs)
  const n = Number(process.env.TRUST_PROXY);
  app.set('trust proxy', Number.isFinite(n) ? n : process.env.TRUST_PROXY);
}

// ---- Security headers ----
const CSP = [
  "default-src 'self'", "script-src 'self'", "style-src 'self' 'unsafe-inline'", "img-src 'self' data:",
  "media-src 'self'", "font-src 'self'", "connect-src 'self'", "object-src 'none'", "base-uri 'self'",
  "form-action 'self'", "frame-ancestors 'none'"
].join('; ') + (PROD ? '; upgrade-insecure-requests' : '');
app.use((req, res, next) => {
  if (process.env.FORCE_HTTPS === '1' && !req.secure) return res.redirect(301, 'https://' + req.headers.host + req.originalUrl);
  res.setHeader('Content-Security-Policy', CSP);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=(), usb=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  if (PROD || req.secure) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
});

// ---- Simple in-memory rate limiter (per client IP) ----
function limiter({ windowMs, max, message }) {
  const hits = new Map();
  setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (v.reset < now) hits.delete(k); }, windowMs).unref();
  return (req, res, next) => {
    const now = Date.now(); let e = hits.get(req.ip);
    if (!e || e.reset < now) { e = { n: 0, reset: now + windowMs }; hits.set(req.ip, e); }
    if (++e.n > max) {
      res.setHeader('Retry-After', Math.ceil((e.reset - now) / 1000));
      return res.status(429).json({ ok: false, message });
    }
    next();
  };
}
app.use('/api', limiter({ windowMs: 60e3, max: 120, message: 'Too many requests. Please slow down and try again shortly.' }));

// ---- Body parsing + same-origin check for anything that changes data ----
app.use(express.json({ limit: '12mb', type: 'application/json' }));
app.use('/api', (req, res, next) => {
  if (req.method === 'GET' || req.method === 'HEAD') return next();
  const origin = req.headers.origin;
  if (origin) { try { if (new URL(origin).host !== req.headers.host) throw 0; } catch { return res.status(403).json({ ok: false, message: 'Request blocked.' }); } }
  next();
});

// ---- Static files (only /public is served; mun.db, config.json and server.js are NOT reachable) ----
app.use((req, res, next) => {
  if (req.path === '/admin.html') { res.setHeader('X-Robots-Tag', 'noindex, nofollow'); res.setHeader('Cache-Control', 'no-store'); }
  next();
});
app.use(express.static(path.join(__dirname, 'public'), { dotfiles: 'ignore' }));

// ---- Registration ----
const FIELDS = ['full_name','guardian','dob','gender','email','phone','whatsapp','institution','grade','student_id','committee','experienced','experience','reason','cnic','ambassador_code'];
const REQUIRED = ['full_name','guardian','institution','gender','email','phone','whatsapp','committee','experienced','reason','cnic'];
const MAXLEN = { email: 254, phone: 20, whatsapp: 20, emergency_phone: 20, dob: 10, gender: 10, experienced: 3, grade: 40, student_id: 60, experience: 1000, reason: 1000, dietary: 300, ambassador_code: 60 };
const phoneOk = v => /^\+?[0-9\s-]{10,15}$/.test(v);
const emailOk = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const clean = (v, max) => (typeof v === 'string' || typeof v === 'number')
  ? String(v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').trim().slice(0, max) : '';
const dobOk = v => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
  const d = new Date(v + 'T00:00:00Z');
  return !isNaN(d) && d.toISOString().slice(0, 10) === v && d <= new Date() && d.getUTCFullYear() >= 1950;
};

app.get('/api/config', (req, res) => res.json(config));

// ---- Payment details + transaction screenshot (shared by delegate and observer forms) ----
// NOTE: no receiving account is stored here. Method names/instructions come from config.json (paymentMethods).
const payMethodNames = () => (config.paymentMethods || []).map(m => m.name);
function readPayment(b, role) {                       // role: 'Delegates' | 'Observers'
  const errors = {};
  const plan = clean(b.fee_plan, 40), method = clean(b.payment_method, 60), txn = clean(b.transaction_details, 80);
  if (!plan || !config.fees || !config.fees[plan] || config.fees[plan][role] === undefined) errors.fee_plan = 'Choose a fee plan.';
  if (!method || !payMethodNames().includes(method)) errors.payment_method = 'Choose a payment method.';
  if (txn.length < 4) errors.transaction_details = 'Enter the transaction ID / reference number shown on your payment receipt.';
  let shot = null, mime = null;
  const raw = typeof b.screenshot_data === 'string' ? b.screenshot_data : '';
  const k = raw.indexOf(';base64,');
  if (!raw.startsWith('data:image/') || k < 0) errors.screenshot = 'Upload a screenshot of your payment (JPG, PNG or WebP).';
  else {
    const buf = Buffer.from(raw.slice(k + 8), 'base64');
    if (buf.length < 500) errors.screenshot = 'The screenshot file looks empty or corrupted. Please upload it again.';
    else if (buf.length > 4 * 1024 * 1024) errors.screenshot = 'The screenshot is too large (max 4 MB).';
    else if (buf[0] === 0xFF && buf[1] === 0xD8 && buf[2] === 0xFF) mime = 'image/jpeg';
    else if (buf[0] === 0x89 && buf.toString('latin1', 1, 4) === 'PNG') mime = 'image/png';
    else if (buf.toString('latin1', 0, 4) === 'RIFF' && buf.toString('latin1', 8, 12) === 'WEBP') mime = 'image/webp';
    else errors.screenshot = 'Only JPG, PNG or WebP images are accepted.';
    if (mime) shot = buf.toString('base64');
  }
  const amount = !errors.fee_plan ? String(config.fees[plan][role]) : '';
  return { errors, values: { fee_plan: plan, amount, payment_method: method, transaction_details: txn, screenshot_data: shot, screenshot_mime: mime } };
}
const submitLimiter = limiter({ windowMs: 10 * 60e3, max: 40, message: 'Too many submissions from this network. Please wait a few minutes and try again.' });

app.post('/api/register', submitLimiter, (req, res) => {
  const body = req.body && typeof req.body === 'object' ? req.body : {};
  // Honeypot: real visitors never see/fill this hidden field, bots usually do. Pretend success, save nothing.
  if (clean(body.website, 50)) return res.json({ ok: true, id: 'MRF-' + crypto.randomBytes(4).toString('hex').toUpperCase() });
  const d = {};
  FIELDS.forEach(f => d[f] = clean(body[f], MAXLEN[f] || 150));
  const errors = {};
  REQUIRED.forEach(f => { if (!d[f]) errors[f] = 'This field is required.'; });
  if (d.email && !emailOk(d.email)) errors.email = 'Enter a valid email address.';
  ['phone','whatsapp'].forEach(f => { if (d[f] && !phoneOk(d[f])) errors[f] = 'Enter a valid phone number.'; });
  if (d.dob && !dobOk(d.dob)) errors.dob = 'Enter a valid date of birth.';
  if (d.cnic && !/^[0-9]{5}-[0-9]{7}-[0-9]{1}$/.test(d.cnic)) errors.cnic = 'Enter CNIC as 12345-1234567-1.';
  if (d.gender && !['Male', 'Female', 'Other'].includes(d.gender)) errors.gender = 'Choose a gender from the list.';
  if (d.experienced && !['Yes', 'No'].includes(d.experienced)) errors.experienced = 'Choose Yes or No.';
  if (d.committee && !config.committees.some(c => c.name === d.committee)) errors.committee = 'Choose a committee from the list.';
  if (d.experienced === 'Yes' && !d.experience) errors.experience = 'Please describe your experience.';
  if (body.accurate !== true || body.consent !== true) errors.consent = 'Both confirmations are required.';
  const pay = readPayment(body, 'Delegates'); Object.assign(errors, pay.errors);
  if (Object.keys(errors).length) return res.status(400).json({ ok: false, errors });
  d.email = d.email.toLowerCase();
  const id = 'MRF-' + crypto.randomBytes(4).toString('hex').toUpperCase();
  const PAYCOLS = ['fee_plan', 'amount', 'payment_method', 'transaction_details', 'screenshot_data', 'screenshot_mime'];
  try {
    // A rejected registration may be re-submitted with the same email (e.g. wrong screenshot): free the email on the old record.
    const old = db.prepare('SELECT id FROM registrations WHERE email=? AND registration_status=?').get(d.email, 'Declined');
    if (old) db.prepare("UPDATE registrations SET email = email || '#rejected-' || id WHERE id=?").run(old.id);
    db.prepare(`INSERT INTO registrations (id,${FIELDS.join(',')},${PAYCOLS.join(',')}) VALUES (@id,${FIELDS.map(f => '@' + f).join(',')},${PAYCOLS.map(f => '@' + f).join(',')})`).run({ id, ...d, ...pay.values });
    const serial = assignSerial('registrations', id);
    res.json({ ok: true, id, status: 'Pending review' });
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return res.status(409).json({ ok: false, errors: { email: 'This email is already registered.' } });
    console.error('Registration save failed:', e.message); res.status(500).json({ ok: false, message: 'Could not save your registration. Please try again.' });
  }
});

app.post('/api/register-observer', submitLimiter, (req, res) => {
  const b = req.body && typeof req.body === 'object' ? req.body : {};
  const d = { full_name: clean(b.full_name, 150), email: clean(b.email, 254).toLowerCase(), institution: clean(b.institution, 180), phone: clean(b.phone, 20), interest: clean(b.interest, 1000) || '', ambassador_code: clean(b.ambassador_code, 60) };
  const errors = {};
  if (!d.full_name || !d.institution) errors.required = 'Please complete all required observer fields.';
  if (!emailOk(d.email)) errors.email = 'Enter a valid email address.';
  if (!phoneOk(d.phone)) errors.phone = 'Enter a valid contact number.';
  const pay = readPayment(b, 'Observers'); Object.assign(errors, pay.errors);
  if (Object.keys(errors).length) return res.status(400).json({ ok: false, errors, message: Object.values(errors)[0] });
  const id = 'MRF-OBS-' + crypto.randomBytes(4).toString('hex').toUpperCase();
  try {
    db.prepare('INSERT INTO observer_registrations (id,full_name,email,institution,phone,interest,ambassador_code,fee_plan,amount,payment_method,transaction_details,screenshot_data,screenshot_mime) VALUES (@id,@full_name,@email,@institution,@phone,@interest,@ambassador_code,@fee_plan,@amount,@payment_method,@transaction_details,@screenshot_data,@screenshot_mime)').run({ id, ...d, ...pay.values });
    const serial = assignSerial('observer_registrations', id);
    res.json({ ok: true, id, status: 'Pending review' });
  } catch (e) { console.error('Observer registration save failed:', e.message); res.status(500).json({ ok: false, message: 'Could not save observer registration. Please try again.' }); }
});

// Public registration-status lookup by opaque registration ID.
app.get('/api/registration-status/:id', (req,res) => {
  const id = String(req.params.id || '').slice(0,40);
  const row = db.prepare('SELECT id, registration_status, review_message FROM registrations WHERE id=?').get(id)
    || db.prepare('SELECT id, registration_status, review_message FROM observer_registrations WHERE id=?').get(id);
  res.setHeader('Cache-Control','no-store');
  if (!row) return res.status(404).json({ok:false,status:'Not found',message:'Transaction not found. Please contact the MRF MUN registration team.'});
  res.json({ok:true,id:row.id,status:row.registration_status || 'Pending review',message:row.review_message || ''});
});

// Public "Check Status": the visitor pastes the Registration ID (MRF-XXXXXXXX or MRF-OBS-XXXXXXXX) they received on submit.
// Pending and Rejected show only the status. Approved also shows the Delegate No. or Observer No. and the name, role, institution and committee.
const statusLimiter = limiter({ windowMs: 10 * 60e3, max: 30, message: 'Too many status checks. Please wait a few minutes and try again.' });
app.get('/api/check-status/:tid', statusLimiter, (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  const id = String(req.params.tid || '').trim().toUpperCase().slice(0, 20);
  if (!/^MRF(-OBS)?-[0-9A-F]{8}$/.test(id)) return res.status(400).json({ ok: false, message: 'Enter a valid Registration ID, for example MRF-1A2B3C4D.' });
  const delegate = !id.startsWith('MRF-OBS-'), table = delegate ? 'registrations' : 'observer_registrations';
  const row = db.prepare(`SELECT registration_status, tracking_id, full_name, institution${delegate ? ', committee' : ''} FROM ${table} WHERE id=?`).get(id);
  if (!row) return res.status(404).json({ ok: false, message: 'No registration found for this Registration ID. Please check it and try again.' });
  const st = row.registration_status || 'Pending review';
  const status = st === 'Accepted' ? 'Approved' : st === 'Declined' ? 'Rejected' : 'Pending';
  const out = { ok: true, status, message:
    status === 'Approved' ? 'Your registration has been approved. Please keep your ' + NUM_LABEL[table] + ' safe.'
    : status === 'Rejected' ? 'Your registration was rejected. Please contact the MRF MUN registration team.'
    : 'Your registration is pending. The organizers are still reviewing your details and transaction.' };
  if (status === 'Approved' && row.tracking_id) {
    out.tracking_id = row.tracking_id; out.number_label = NUM_LABEL[table];
    out.details = [['Name', row.full_name], ['Registered as', delegate ? 'Delegate' : 'Observer'], ['Institution', row.institution]];
    if (delegate && row.committee) out.details.push(['Committee', row.committee]);
  }
  res.json(out);
});

// ---- Admin: password login -> random session token in an HttpOnly, SameSite=Strict cookie ----
const sessions = new Map(); const failures = new Map();
setInterval(() => { const now = Date.now(); for (const [t, exp] of sessions) if (exp < now) sessions.delete(t); for (const [ip, f] of failures) if (f.reset < now) failures.delete(ip); }, 10 * 60e3).unref();
const cookieToken = req => {
  const m = (req.headers.cookie || '').split(';').map(s => s.trim()).find(c => c.startsWith('adm='));
  return m ? m.slice(4) : '';
};
const cookieAttrs = req => `HttpOnly; SameSite=Strict; Path=/${(PROD || req.secure) ? '; Secure' : ''}`;
const sha = s => crypto.createHash('sha256').update(String(s)).digest();
const requireAdmin = (req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  const exp = sessions.get(cookieToken(req));
  if (exp && exp > Date.now()) return next();
  res.status(401).json({ ok: false });
};
app.post('/api/admin/login', (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  const now = Date.now(); let f = failures.get(req.ip);
  if (!f || f.reset < now) { f = { n: 0, reset: now + 15 * 60e3 }; failures.set(req.ip, f); }
  if (f.n >= 5) {
    res.setHeader('Retry-After', Math.ceil((f.reset - now) / 1000));
    return res.status(429).json({ ok: false, message: `Too many wrong attempts. Try again in ${Math.ceil((f.reset - now) / 60000)} minute(s).` });
  }
  const given = req.body && typeof req.body.password === 'string' ? req.body.password : '';
  if (!crypto.timingSafeEqual(sha(given), sha(ADMIN_PASSWORD))) {
    f.n++; console.warn('Failed admin login from', req.ip);
    return res.status(401).json({ ok: false, message: 'Wrong password.' });
  }
  failures.delete(req.ip);
  const t = crypto.randomBytes(32).toString('hex'); sessions.set(t, now + 8 * 3600e3);
  res.setHeader('Set-Cookie', `adm=${t}; ${cookieAttrs(req)}; Max-Age=28800`);
  res.json({ ok: true });
});
app.post('/api/admin/logout', (req, res) => {
  sessions.delete(cookieToken(req));
  res.setHeader('Set-Cookie', `adm=; ${cookieAttrs(req)}; Max-Age=0`);
  res.json({ ok: true });
});
const PAYSEL = 'fee_plan,amount,payment_method,transaction_details,(screenshot_data IS NOT NULL) AS has_screenshot';
const query = req => {
  const q = `%${String(req.query.q || '').slice(0, 100)}%`, c = String(req.query.committee || '').slice(0, 100);
  return db.prepare(`SELECT id,serial,created_at,${FIELDS.join(',')},registration_status,review_message,tracking_id,${PAYSEL} FROM registrations WHERE (full_name LIKE ? OR email LIKE ? OR id LIKE ? OR institution LIKE ?) AND (?='' OR committee=?) ORDER BY created_at DESC`).all(q, q, q, q, c, c);
};
app.get('/api/admin/registrations', requireAdmin, (req, res) => res.json(query(req)));
app.get('/api/admin/observers', requireAdmin, (req, res) => {
  const q = `%${String(req.query.q || '').slice(0, 100)}%`;
  res.json(db.prepare(`SELECT id,serial,created_at,full_name,email,institution,phone,interest,registration_status,review_message,tracking_id,${PAYSEL} FROM observer_registrations WHERE full_name LIKE ? OR email LIKE ? OR id LIKE ? OR institution LIKE ? ORDER BY created_at DESC`).all(q, q, q, q));
});
// Transaction screenshot as a real image (shown in <img> on the admin page; admin login required)
function sendShot(table, req, res) {
  const row = db.prepare(`SELECT screenshot_data,screenshot_mime FROM ${table} WHERE id=?`).get(String(req.params.id).slice(0, 40));
  if (!row || !row.screenshot_data) return res.status(404).json({ ok: false, message: 'Screenshot not found.' });
  res.setHeader('Content-Type', row.screenshot_mime || 'image/jpeg');
  res.setHeader('Cache-Control', 'private, max-age=300');
  res.setHeader('Content-Disposition', 'inline');
  res.send(Buffer.from(row.screenshot_data, 'base64'));
}
app.get('/api/admin/registrations/:id/screenshot.img', requireAdmin, (req, res) => sendShot('registrations', req, res));
app.get('/api/admin/observers/:id/screenshot.img', requireAdmin, (req, res) => sendShot('observer_registrations', req, res));
function reviewRegistration(table, req, res) {
  const action=String(req.body.action||'');
  if(!['Accepted','Declined'].includes(action)) return res.status(400).json({ok:false,message:'Invalid review action.'});
  const row=db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(req.params.id);
  if(!row) return res.status(404).json({ok:false,message:'Registration not found.'});
  const required = table==='registrations' ? ['full_name','guardian','institution','gender','email','phone','whatsapp','committee','experienced','reason','cnic'] : ['full_name','email','institution','phone'];
  const missing=required.filter(k=>!String(row[k]||'').trim());
  if(action==='Accepted' && !row.screenshot_data) return res.status(400).json({ok:false,message:'Cannot accept: no transaction screenshot was uploaded for this registration.'});
  if(action==='Accepted' && missing.length) return res.status(400).json({ok:false,message:'Cannot accept: required observer details are missing.',missing});
  const message=action==='Accepted' ? (table==='observer_registrations' ? 'Your registration has been reviewed and is successful.' : 'Your transaction has been reviewed and your registration is successful.') : (table==='observer_registrations' ? 'Your registration was declined. Please contact the MRF MUN registration team.' : 'Transaction not found or could not be verified. Your registration was declined.');
  const sql = table==='observer_registrations' ? 'UPDATE observer_registrations SET registration_status=?, review_message=?, payment_status=? WHERE id=?' : 'UPDATE registrations SET registration_status=?, review_message=? WHERE id=?';
  const args = table==='observer_registrations' ? [action,message,action==='Accepted'?'Verified':'Rejected',req.params.id] : [action,message,req.params.id];
  const result=db.prepare(sql).run(...args);
  if(action==='Accepted' && result.changes===1 && !row.tracking_id) db.prepare(`UPDATE ${table} SET tracking_id=? WHERE id=?`).run(nextNumber(table), req.params.id);
  res.json({ok:result.changes===1,status:action,message});
}
// Admin: delete ALL registrations (Pending, Accepted, Rejected). A backup copy of the database is saved first.
app.post('/api/admin/reset', requireAdmin, (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    const backup = path.join(path.dirname(DB_FILE), 'mun-backup-' + new Date().toISOString().replace(/[:.]/g, '-') + '.db');
    db.exec('PRAGMA wal_checkpoint(FULL)');
    fs.copyFileSync(DB_FILE, backup);            // if this fails, nothing is deleted
    const dN = db.prepare('SELECT COUNT(*) AS n FROM registrations').get().n;
    const oN = db.prepare('SELECT COUNT(*) AS n FROM observer_registrations').get().n;
    db.exec('DELETE FROM registrations; DELETE FROM observer_registrations;');
    res.json({ ok: true, deletedDelegates: dN, deletedObservers: oN, backup: path.basename(backup) });
  } catch (e) {
    res.status(500).json({ ok: false, message: 'Reset failed. Nothing was deleted. Please try again.' });
  }
});
app.post('/api/admin/registrations/:id/review', requireAdmin, (req,res)=>reviewRegistration('registrations',req,res));
app.post('/api/admin/observers/:id/review', requireAdmin, (req,res)=>reviewRegistration('observer_registrations',req,res));
app.post('/api/admin/observers/:id/status', requireAdmin, (req,res) => { const status=String(req.body.status||''); if(!['Verified','Rejected','Pending verification'].includes(status)) return res.status(400).json({ok:false}); const result=db.prepare('UPDATE observer_registrations SET payment_status=? WHERE id=?').run(status,req.params.id); res.json({ok:result.changes===1}); });
// CSV helpers: risky characters are prefixed so spreadsheets don't run cell contents as formulas (plain phone numbers are left alone)
const csvEsc = v => { v = String(v ?? ''); if (/^[=+\-@\t\r]/.test(v) && !/^\+?[0-9][0-9\s()-]*$/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; };
const sendCsv = (res, filename, cols, rows) => res.type('text/csv').attachment(filename).send('\ufeff' + [cols.map(c => csvEsc(c[1])).join(','), ...rows.map(r => cols.map(c => csvEsc(r[c[0]])).join(','))].join('\r\n'));
// Delegate registrations only
app.get('/api/admin/export.csv', requireAdmin, (req, res) => {
  sendCsv(res, 'mrf-mun-registrations.csv', [
    ['tracking_id','Delegate No.'], ['full_name','Full name'], ['email','Email'], ['guardian','Guardian name'], ['institution','Institution'],
    ['committee','Committee'], ['cnic','CNIC No.'], ['fee_plan','Fee Plan'], ['transaction_details','Transaction details']
  ], query(req).map(r => ({ ...r, tracking_id: r.registration_status === 'Accepted' ? r.tracking_id : '' })));
});
// Observer registrations only
app.get('/api/admin/observers-export.csv', requireAdmin, (req, res) => {
  const q = `%${String(req.query.q || '').slice(0, 100)}%`;
  const rows = db.prepare('SELECT id,serial,created_at,full_name,email,institution,phone,interest,fee_plan,amount,payment_method,transaction_details,registration_status,tracking_id FROM observer_registrations WHERE full_name LIKE ? OR email LIKE ? OR id LIKE ? OR institution LIKE ? ORDER BY created_at DESC').all(q, q, q, q);
  sendCsv(res, 'mrf-mun-observers.csv', [
    ['tracking_id','Observer No.'], ['full_name','Full name'], ['email','Email'], ['phone','Contact no.'], ['institution','Institution'],
    ['fee_plan','Fee plan'], ['transaction_details','Transaction Details']
  ], rows.map(r => ({ ...r, tracking_id: r.registration_status === 'Accepted' ? r.tracking_id : '' })));
});

// ---- Fallbacks: no stack traces or internals are ever sent to visitors ----
app.use('/api', (req, res) => res.status(404).json({ ok: false, message: 'Not found.' }));
app.use((err, req, res, next) => {   // eslint-disable-line no-unused-vars
  if (err && (err.type === 'entity.parse.failed' || err.type === 'entity.too.large')) return res.status(err.status || 400).json({ ok: false, message: 'Invalid request.' });
  console.error('Unexpected error:', err && err.message);
  res.status(500).json({ ok: false, message: 'Something went wrong. Please try again.' });
});

app.listen(process.env.PORT || 3000, () => console.log('MRF MUN running on port ' + (process.env.PORT || 3000)));
