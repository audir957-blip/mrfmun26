// MRF MUN front end: loads config, validates the form, submits to the backend.
const $ = s => document.querySelector(s);
const form = $('#regForm'), btn = $('#submitBtn');
$('#year').textContent = new Date().getFullYear();
function esc(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

// 1. Fill committees, countries and event info from the server (config.json)
const localFallback = {
  committees: [
    { name: "PNA – Pakistan National Assembly", title: "Pakistan National Assembly", logo: "assets/committees/PNA.png", description: "A parliamentary-style forum for debating public policy, representing constituents and developing practical proposals through discussion.", seats: 0 },
    { name: "UNSC – United Nations Security Council", title: "United Nations Security Council", logo: "assets/committees/UNSC.png", description: "International peace and security, conflict resolution and collective action.", seats: 0 },
    { name: "UNHRC – United Nations Human Rights Council", title: "United Nations Human Rights Council", logo: "assets/committees/UNHRC.png", description: "Promotion and protection of human rights around the world.", seats: 0 },
    { name: "UNCSW – Commission on the Status of Women", title: "United Nations Commission on the Status of Women", logo: "assets/committees/UNCSW.png", description: "Gender equality and the empowerment of women and girls.", seats: 0 },
    { name: "WHO – World Health Organization", title: "World Health Organization", logo: "assets/committees/WHO.png", description: "Global public health, health systems and international cooperation on health crises.", seats: 0 },
    { name: "SCC – Special Crisis Cell", title: "Special Crisis Cell", logo: "assets/committees/SCC.png", description: "A focused crisis committee where delegates assess fast-moving developments, negotiate responses and make time-sensitive decisions.", seats: 0 }
  ],

  countries: ["Pakistan","China","United States","United Kingdom","France","Russia","India","Turkey","Saudi Arabia","Japan","Germany","Brazil","Egypt","Iran","Indonesia"],
  info: {"Event Dates": {"days": ["1st", "2nd", "3rd"], "month": "January 2027"}, "Venue": "Fazaia Degree College MRF Kamra", "Early Birds Deadline": "29 November 2026"},
  paymentMethods: [{ name: "Bank Transfer", details: "Bank: HBL\nAccount Title: Nusret\nAccount Number: 179000 79677703" }],
  fees: {"Early Birds": {"Delegates": "Rs 3000", "Observers": "Rs 3500"}},
  feesDisplayOnly: {"Regular": {"Delegates": "Rs 4500", "Observers": "Rs 4000"}}
};
// Extra details shown in the middle of each committee row (edit the text here any time)
const committeeDetails = {
  PNA:   [['Type', 'National legislature (parliamentary style)'], ['Focus', 'Public policy, bills and national debate'], ['You will practice', 'Debating, drafting proposals, building coalitions']],
  UNSC:  [['Type', 'Principal UN organ for peace and security'], ['Focus', 'Conflicts, sanctions and resolutions'], ['You will practice', 'Negotiation, resolution writing, diplomacy']],
  UNHRC: [['Type', 'Intergovernmental UN human rights body'], ['Focus', 'Human rights situations and protections'], ['You will practice', 'Research, advocacy, public speaking']],
  UNCSW: [['Type', 'UN commission under ECOSOC'], ['Focus', 'Gender equality and empowerment'], ['You will practice', 'Policy analysis, collaboration, persuasion']],
  WHO:   [['Type', 'UN specialized agency'], ['Focus', 'Global health systems and health crises'], ['You will practice', 'Evidence-based debate, cooperation, problem solving']],
  SCC:   [['Type', 'Crisis committee (fast-paced)'], ['Focus', 'Fast-moving developments and urgent decisions'], ['You will practice', 'Quick thinking, teamwork, decision making']]
};
function detailsHtml(acr) {
  const d = committeeDetails[acr];
  return d ? `<dl class="card-details">${d.map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>` : '';
}

let committees = [];
function renderConfig(cfg) {
  committees = cfg.committees || localFallback.committees;
  $('#committeeCards').innerHTML = committees.map(c => {
    const parts = String(c.name).split(' – ');
    const acr = parts[0], full = c.title || parts.slice(1).join(' – ');
    return `<article class="card"><div class="card-text"><h3><span class="acr">${esc(acr)}</span>${full ? `<span class="full">${esc(full)}</span>` : ''}</h3><p>${esc(c.description)}</p><div class="card-meta"><span class="seats">Seats: ${c.seats || 'TBA'}</span><button type="button" class="btn ghost pick btn-sweep" data-name="${esc(c.name)}">Choose this committee</button></div></div>${detailsHtml(acr)}<span class="logo"><img src="${esc(c.logo)}" alt="${esc(c.name)} committee emblem" loading="lazy"></span></article>`;
  }).join('');
  $('#committeeSelect').innerHTML = '<option value="">Select</option>' + committees.map(c => `<option>${esc(c.name)}</option>`).join('');
  $('#info').innerHTML = Object.entries(cfg.info || localFallback.info).map(([k, v]) => {
    if (v && typeof v === 'object' && Array.isArray(v.days)) {
      const days = v.days.map(d => { const p = String(d).match(/^(\d+)(st|nd|rd|th)$/); return `<span class="ev-day">${p ? p[1] + '<sup>' + p[2] + '</sup>' : esc(d)}</span>`; }).join('');
      return `<div class="event-box"><dt>${esc(k)}</dt><dd><span class="ev-days">${days}</span><span class="ev-month">${esc(v.month || '')}</span></dd></div>`;
    }
    return `<div class="${k === 'Early Birds Deadline' ? 'deadline-box' : ''}"><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`;
  }).join('');
  window.__cfg = { fees: cfg.fees || localFallback.fees, paymentMethods: cfg.paymentMethods || localFallback.paymentMethods };
  setupPayment();
  const fees = { ...(cfg.fees || localFallback.fees), ...(cfg.feesDisplayOnly || localFallback.feesDisplayOnly || {}) };
  $('#fees').innerHTML = `<h3>Fee Structure</h3><div class="fee-cols">${Object.entries(fees).map(([plan, rows]) => `<div class="fee-col"><h4>${esc(plan)}</h4>${Object.entries(rows).map(([who, amt]) => `<div class="fee-row"><span>${esc(who)}</span><b>${esc(amt)}</b></div>`).join('')}</div>`).join('')}</div>`;
}
fetch('/api/config').then(r => { if (!r.ok) throw new Error('Config unavailable'); return r.json(); })
  .then(renderConfig)
  .catch(() => renderConfig(localFallback));
// Card button: pre-select the committee in the form and jump to it
$('#committeeCards').addEventListener('click', e => {
  const b = e.target.closest('.pick'); if (!b) return;
  $('#committeeSelect').value = b.dataset.name; $('#committeeSelect').dispatchEvent(new Event('change')); location.hash = '#registration'; $('#committeeSelect').focus();
});

// 2. Show the experience box only when "Yes" is chosen
$('#experienced').addEventListener('change', e => { $('#expWrap').hidden = e.target.value !== 'Yes'; });

// 3. Validation: errors appear next to each field
function setError(el, msg) {
  let box = el.parentElement.querySelector('.err');
  if (!box) { box = document.createElement('span'); box.className = 'err'; el.parentElement.appendChild(box); }
  box.textContent = msg; el.classList.toggle('bad', !!msg); el.setAttribute('aria-invalid', !!msg);
}
function validate() {
  let ok = true;
  form.querySelectorAll('input[required],select[required],textarea[required]').forEach(el => {
    const v = el.value.trim(); let msg = '';
    if (!v) msg = 'This field is required.';
    else if (el.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) msg = 'Enter a valid email address.';
    else if (el.type === 'tel' && !/^\+?[0-9\s-]{10,15}$/.test(v)) msg = 'Enter a valid phone number (10–15 digits).';
    setError(el, msg); if (msg) ok = false;
  });
  const needExp = form.experienced.value === 'Yes' && !form.experience.value.trim();
  setError(form.experience, needExp ? 'Please describe your experience.' : ''); if (needExp) ok = false;
  const fileErr = checkShot(form.querySelector('.pay-file')); setError(form.querySelector('.pay-file'), fileErr); if (fileErr) ok = false;
  const unticked = !form.accurate.checked || !form.consent.checked;
  $('[data-for=consent]').textContent = unticked ? 'Please tick both confirmations.' : ''; if (unticked) ok = false;
  return ok;
}

async function watchRegistrationStatus(id, target) {
  const check=async()=>{try{const r=await fetch('/api/registration-status/'+encodeURIComponent(id),{cache:'no-store'});const o=await r.json();if(o.ok && o.status!=='Pending review'){target.textContent=o.status==='Accepted'?'REGISTRATION SUCCESSFUL! Your transaction has been reviewed and your registration is confirmed.':'TRANSACTION NOT FOUND. Your registration was declined. Please contact the MRF MUN team.';return true;} }catch{} return false;};
  if(await check())return; const timer=setInterval(async()=>{if(await check())clearInterval(timer);},10000);
}

// 4. Submit once; success shows only after the server confirms the save
form.addEventListener('submit', async e => {
  e.preventDefault(); $('#formMsg').textContent = '';
  if (btn.disabled) return;
  if (!validate()) { const bad = form.querySelector('.bad'); if (bad) bad.focus(); return; }
  btn.disabled = true; btn.textContent = 'Submitting…';
  const data = Object.fromEntries(new FormData(form)); data.accurate = form.accurate.checked; data.consent = form.consent.checked;
  try {
    delete data.screenshot; data.screenshot_data = await fileToDataUrl(form.querySelector('.pay-file').files[0]);
    const res = await fetch('/api/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
    const out = await res.json();
    if (out.ok) { form.hidden = true; $('#regId').textContent = out.id; $('#success').hidden = false; $('#success').focus(); watchRegistrationStatus(out.id,$('#delegateReviewStatus')); return; }
    Object.entries(out.errors || {}).forEach(([k, m]) => { const el = form.elements[k]; if (el && el.type !== 'checkbox') setError(el, m); });
    $('#formMsg').textContent = out.message || 'Please fix the highlighted fields.';
  } catch { $('#formMsg').textContent = 'Network error. Your registration was NOT saved. Please try again.'; }
  btn.disabled = false; btn.textContent = 'Submit Registration';
});
$('#resetBtn').addEventListener('click', () => setTimeout(() => {
  form.querySelectorAll('.err').forEach(e => e.textContent = ''); form.querySelectorAll('.bad').forEach(e => e.classList.remove('bad')); $('#expWrap').hidden = true; $('#cpreview').style.display = 'none'; form.querySelectorAll('.pay-preview').forEach(i => i.hidden = true); form.querySelectorAll('.pay-info').forEach(updatePayInfo);
}));

// Show the chosen committee's picture next to the dropdown
$('#committeeSelect').addEventListener('change', e => {
  const c = committees.find(x => x.name === e.target.value), img = $('#cpreview');
  img.style.display = c ? 'block' : 'none'; if (c) img.src = c.logo;
});


// Registration category chooser and observer payment-proof preview.
const delegatePanel = $('#delegatePanel'), observerPanel = $('#observerPanel'), statusPanel = $('#statusPanel');
document.querySelectorAll('[data-registration]').forEach(button => button.addEventListener('click', () => {
  const choices = $('#registrationChoices');
  const wait = matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 250;
  choices.classList.add('fade-out');   // buttons fade away first, then the form slides in smoothly
  setTimeout(() => {
    choices.classList.remove('fade-out');
    delegatePanel.hidden = button.dataset.registration !== 'delegate';
    observerPanel.hidden = button.dataset.registration !== 'observer';
    statusPanel.hidden = button.dataset.registration !== 'status';
    choices.hidden = true;
    ({ delegate: delegatePanel, observer: observerPanel, status: statusPanel })[button.dataset.registration].scrollIntoView({behavior:'smooth',block:'start'});
  }, wait);
}));
$('#backToChoices').addEventListener('click', () => { observerPanel.hidden = true; $('#registrationChoices').hidden = false; });
// ---- Check Status: search by Registration ID ----
function statusHtml(o) {
  const cls = o.status === 'Approved' ? 'approved' : o.status === 'Rejected' ? 'rejected' : 'pending';
  let h = `<div class="status-card ${cls}"><div class="status-head"><span class="status-badge">${esc(o.status)}</span></div><p>${esc(o.message)}</p>`;
  if (o.status === 'Approved') {
    const role = o.number_label === 'Delegate No.' ? 'Delegate' : 'Observer';
    h += `<div class="tracking">${esc(o.number_label)}<strong>${esc(o.tracking_id)}</strong></div><dl class="status-details">${(o.details || []).map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>`;
    h += `<div class="serial-msg"><h3>MRF MUN 26 (As ${role})</h3><p>Thankyou for registering for MRF MUN.</p><p>Note: Plz show this on the event day to get your card.(Bring screenshot of this message)</p></div>`;
  }
  return h + '</div>';
}
$('#statusBack').addEventListener('click', () => {
  statusPanel.hidden = true; $('#registrationChoices').hidden = false;
  $('#statusTid').value = ''; $('#statusMsg').textContent = ''; $('#statusResult').hidden = true; $('#statusResult').innerHTML = '';
});
$('#statusForm').addEventListener('submit', async e => {
  e.preventDefault();
  const msg = $('#statusMsg'), out = $('#statusResult'), go = $('#statusSubmit');
  const tid = $('#statusTid').value.trim().toUpperCase();
  msg.textContent = ''; out.hidden = true; out.innerHTML = '';
  if (!/^MRF(-OBS)?-[0-9A-F]{8}$/.test(tid)) { msg.textContent = 'Enter your Registration ID, for example MRF-1A2B3C4D.'; return; }
  go.disabled = true; go.textContent = 'Searching…';
  try {
    const r = await fetch('/api/check-status/' + encodeURIComponent(tid), { cache: 'no-store' });
    const o = await r.json();
    if (!r.ok || !o.ok) throw new Error(o.message || 'Could not check the status. Please try again.');
    out.innerHTML = statusHtml(o); out.hidden = false;
  } catch (err) { msg.textContent = err.message || 'Network error. Please try again.'; }
  go.disabled = false; go.textContent = 'Search';
});
$('#delegateBack').addEventListener('click', () => { delegatePanel.hidden = true; $('#registrationChoices').hidden = false; });
$('#observerReset').addEventListener('click', () => setTimeout(() => {
  const f = $('#observerForm'); $('#observerMsg').textContent = '';
  f.querySelectorAll('.bad').forEach(e => e.classList.remove('bad')); f.querySelectorAll('.pay-preview').forEach(i => i.hidden = true); f.querySelectorAll('.pay-info').forEach(updatePayInfo);
}));
$('#observerForm').addEventListener('submit', async e => {
  e.preventDefault(); const f=e.currentTarget, msg=$('#observerMsg'); msg.textContent='';
  if (!f.reportValidity()) return;
  const fileErr = checkShot(f.querySelector('.pay-file')); if (fileErr) { msg.textContent = fileErr; return; }
  const data=Object.fromEntries(new FormData(f));
  const submit=$('#observerSubmit'); submit.disabled=true; submit.textContent='Submitting…';
  try {
    delete data.screenshot; data.screenshot_data = await fileToDataUrl(f.querySelector('.pay-file').files[0]);
    const response=await fetch('/api/register-observer',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    const result=await response.json();
    if(!response.ok || !result.ok) throw new Error(result.message || 'Registration could not be saved.');
    $('#observerRegId').textContent=result.id; f.hidden=true; $('#observerSuccess').hidden=false; $('#observerSuccess').focus(); watchRegistrationStatus(result.id,$('#observerReviewStatus'));
  } catch(error) { msg.textContent=error.message || 'Network error. Please try again.'; }
  submit.disabled=false; submit.textContent='Submit Registration';
});


// ---- Payment section (same code for Delegate and Observer forms) ----
// Receiving account details are NOT hard-coded: they come from "paymentMethods" in config.json (empty for now).
const MAX_SHOT = 12 * 1024 * 1024;   // raw file limit before compression
function checkShot(input) {
  const f = input.files && input.files[0];
  if (!f) return 'Please upload your payment screenshot.';
  if (!/^image\/(jpeg|png|webp)$/.test(f.type)) return 'Only JPG, PNG or WebP images are accepted.';
  if (f.size > MAX_SHOT) return 'This image is too large. Please upload a smaller screenshot.';
  return '';
}
// Shrink big phone screenshots in the browser (max 1600px, JPEG) so uploads stay fast; falls back to the original file.
async function fileToDataUrl(file) {
  const readRaw = () => new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = no; r.readAsDataURL(file); });
  try {
    const bmp = await createImageBitmap(file);
    const scale = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
    const c = document.createElement('canvas'); c.width = Math.round(bmp.width * scale); c.height = Math.round(bmp.height * scale);
    const ctx = c.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); ctx.drawImage(bmp, 0, 0, c.width, c.height);
    const url = c.toDataURL('image/jpeg', 0.82);
    return url.length < 5.2 * 1024 * 1024 ? url : readRaw();
  } catch { return readRaw(); }
}
function planAmount(role, plan) { const p = (window.__cfg.fees || {})[plan]; return p ? p[role] : ''; }
function updatePayInfo(box) {
  const fs = box.closest('.pay'), role = fs.dataset.role;
  const plan = fs.querySelector('.pay-plan').value, name = fs.querySelector('.pay-method').value;
  const amt = plan ? planAmount(role, plan) : '', m = (window.__cfg.paymentMethods || []).find(x => x.name === name);
  box.querySelector('.pay-amount').textContent = amt ? `Amount to pay: ${amt}` : '';
  box.querySelector('.pay-instructions').textContent = !name ? 'Select a fee plan and payment method to see how to pay.'
    : (m && m.details ? m.details : `${name} account details will be shared here by the organizers.`);
}
function setupPayment() {
  document.querySelectorAll('.pay').forEach(fs => {
    const role = fs.dataset.role, fees = window.__cfg.fees || {}, info = fs.querySelector('.pay-info');
    const plan = fs.querySelector('.pay-plan'), method = fs.querySelector('.pay-method');
    plan.innerHTML = '<option value="">Select</option>' + Object.keys(fees).filter(p => fees[p][role] !== undefined).map(p => `<option value="${esc(p)}">${esc(p)} — ${esc(fees[p][role])}</option>`).join('');
    method.innerHTML = '<option value="">Select</option>' + (window.__cfg.paymentMethods || []).map(m => `<option value="${esc(m.name)}">${esc(m.name)}</option>`).join('');
    if (!fs.dataset.bound) {
      fs.dataset.bound = '1';
      plan.addEventListener('change', () => updatePayInfo(info)); method.addEventListener('change', () => updatePayInfo(info));
      const file = fs.querySelector('.pay-file'), prev = fs.querySelector('.pay-preview');
      file.addEventListener('change', () => {
        const err = checkShot(file), f = file.files[0];
        if (!err && f) { const r = new FileReader(); r.onload = () => { prev.src = r.result; prev.hidden = false; }; r.readAsDataURL(f); } else { prev.hidden = true; }
        if (file.closest('#regForm')) setError(file, file.files.length ? err : '');
        else if (err && f) $('#observerMsg').textContent = err; else $('#observerMsg').textContent = '';
      });
    }
    updatePayInfo(info);
  });
}

// Clear a field's red error as soon as the user fills it in
['input', 'change'].forEach(ev => form.addEventListener(ev, e => {
  const el = e.target; if (el.classList && el.classList.contains('bad') && el.type !== 'file' && String(el.value).trim()) setError(el, '');
}));
