// Admin dashboard: log in, review each registration (details + payment + screenshot) and Accept / Reject.
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const DELEGATE_FIELDS = [['Email', 'email'], ['Phone', 'phone'], ['WhatsApp', 'whatsapp'], ['CNIC', 'cnic'], ['Date of birth', 'dob'], ['Gender', 'gender'], ['Father/Guardian', 'guardian'],
  ['Institution', 'institution'], ['Class/Grade', 'grade'], ['Student ID', 'student_id'], ['Committee', 'committee'], ['Previous MUN experience', 'experienced'],
  ['Experience details', 'experience', 1], ['Reason for joining', 'reason', 1]];
const OBSERVER_FIELDS = [['Email', 'email'], ['Contact number', 'phone'], ['School / College', 'institution']];
let delegates = [], observers = [];

$('#login').addEventListener('submit', async e => {
  e.preventDefault();
  const r = await fetch('/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: $('#pw').value }) });
  const o = await r.json();
  if (!o.ok) return $('#lerr').textContent = o.message || 'Login failed.';
  $('#login').hidden = true; $('#dash').hidden = false;
  const cfg = await (await fetch('/api/config')).json();
  cfg.committees.forEach(c => $('#cf').insertAdjacentHTML('beforeend', `<option>${esc(c.name)}</option>`));
  load();
});

const statusKey = s => s === 'Accepted' ? 'accepted' : s === 'Declined' ? 'declined' : 'pending';
const statusLabel = s => s === 'Declined' ? 'Rejected' : (s || 'Pending review');
function toast(msg, bad) { const t = $('#toast'); t.textContent = msg; t.classList.toggle('bad', !!bad); t.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => t.hidden = true, 5000); }

function card(x, kind) {
  const base = kind === 'delegate' ? '/api/admin/registrations/' : '/api/admin/observers/';
  const fields = kind === 'delegate' ? DELEGATE_FIELDS : OBSERVER_FIELDS;
  const st = x.registration_status || 'Pending review';
  const trk = st === 'Accepted' && x.tracking_id ? `<div><dt>${kind === 'delegate' ? 'Delegate No.' : 'Observer No.'}</dt><dd>${esc(x.tracking_id)}</dd></div>` : '';
  const rows = trk + fields.filter(([, k]) => String(x[k] ?? '').trim()).map(([l, k, full]) => `<div${full ? ' class="full"' : ''}><dt>${esc(l)}</dt><dd>${esc(x[k])}</dd></div>`).join('');
  const shot = x.has_screenshot
    ? `<button type="button" class="shot" data-shot="${esc(base + encodeURIComponent(x.id) + '/screenshot.img')}" aria-label="Open transaction screenshot full size"><img src="${esc(base + encodeURIComponent(x.id) + '/screenshot.img')}" alt="Transaction screenshot of ${esc(x.full_name)}" loading="lazy"></button><p class="hintz">Click the screenshot to enlarge.</p>`
    : '<div class="noshot">No transaction screenshot uploaded</div>';
  return `<article class="rcard" data-id="${esc(x.id)}">
    <header><div><h4>${esc(x.full_name)}</h4><div class="sub">${esc(x.id)} · submitted ${esc(x.created_at)} UTC</div></div><span class="badge ${statusKey(st)}">${esc(statusLabel(st))}</span></header>
    <dl>${rows}</dl>
    <div class="paybox"><h5>Payment</h5>
      <dl><div><dt>Fee plan</dt><dd>${esc(x.fee_plan || '—')}</dd></div><div><dt>Amount</dt><dd>${esc(x.amount || '—')}</dd></div>
      <div><dt>Method</dt><dd>${esc(x.payment_method || '—')}</dd></div><div><dt>Transaction ID</dt><dd>${esc(x.transaction_details || '—')}</dd></div></dl>
      ${shot}</div>
    <footer><button type="button" class="btn gold" data-review="accept" data-kind="${kind}" data-id="${esc(x.id)}"${st === 'Accepted' ? ' disabled' : ''}>Accept</button>
      <button type="button" class="btn reject" data-review="decline" data-kind="${kind}" data-id="${esc(x.id)}"${st === 'Declined' ? ' disabled' : ''}>Reject</button></footer>
  </article>`;
}
function render() {
  const sf = $('#sf').value, f = a => sf ? a.filter(x => (x.registration_status || 'Pending review') === sf) : a;
  const d = f(delegates), o = f(observers), none = '<div class="empty">No registrations to show.</div>';
  $('#dList').innerHTML = d.length ? d.map(x => card(x, 'delegate')).join('') : none;
  $('#oList').innerHTML = o.length ? o.map(x => card(x, 'observer')).join('') : none;
  $('#count').textContent = `(${d.length})`; $('#observerCount').textContent = `(${o.length})`;
  const all = [...delegates, ...observers], n = s => all.filter(x => (x.registration_status || 'Pending review') === s).length;
  $('#summary').innerHTML = `<span class="chip">Pending: <b>${n('Pending review')}</b></span><span class="chip">Accepted: <b>${n('Accepted')}</b></span><span class="chip">Rejected: <b>${n('Declined')}</b></span><span class="chip">Total: <b>${all.length}</b></span>`;
}
async function load() {
  const p = new URLSearchParams({ q: $('#q').value, committee: $('#cf').value });
  const [r1, r2] = await Promise.all([fetch('/api/admin/registrations?' + p), fetch('/api/admin/observers?' + new URLSearchParams({ q: $('#q').value }))]);
  if (r1.status === 401 || r2.status === 401) return location.reload();
  delegates = await r1.json(); observers = await r2.json();
  $('#expDelegates').href = '/api/admin/export.csv?' + p;
  $('#expObservers').href = '/api/admin/observers-export.csv?' + new URLSearchParams({ q: $('#q').value });
  render();
}
async function submitReview(button) {
  const accept = button.dataset.review === 'accept', action = accept ? 'Accepted' : 'Declined';
  if (!confirm(accept ? 'Accept this registration? The user will see that their registration is successful.' : 'Reject this registration? The user will see that it was declined.')) return;
  button.disabled = true;
  try {
    const base = button.dataset.kind === 'delegate' ? '/api/admin/registrations/' : '/api/admin/observers/';
    const r = await fetch(base + encodeURIComponent(button.dataset.id) + '/review', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action }) });
    if (r.status === 401) return location.reload();
    const o = await r.json(); if (!r.ok || !o.ok) throw new Error(o.message || 'Review failed.');
    toast(accept ? 'Registration accepted.' : 'Registration rejected.'); await load();
  } catch (err) { toast(err.message || 'Could not review registration.', true); button.disabled = false; }
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-review]'); if (b) return submitReview(b);
  const s = e.target.closest('[data-shot]'); if (s) { $('#lbImg').src = s.dataset.shot; $('#lb').showModal(); return; }
  if (e.target === $('#lb') || e.target.closest('#lbClose')) $('#lb').close();
});
$('#lb').addEventListener('close', () => { $('#lbImg').removeAttribute('src'); });
let t; $('#q').addEventListener('input', () => { clearTimeout(t); t = setTimeout(load, 250); });
$('#cf').addEventListener('change', load); $('#sf').addEventListener('change', render);
$('#resetAll').addEventListener('click', async () => {
  if (!confirm('Delete ALL registrations (Pending, Accepted and Rejected) for delegates and observers?\n\nA backup copy is saved on the server first. You cannot undo this from the website.')) return;
  const btn = $('#resetAll'); btn.disabled = true;
  try {
    const r = await fetch('/api/admin/reset', { method: 'POST' });
    const o = await r.json();
    if (!r.ok || !o.ok) throw new Error(o.message || 'Reset failed.');
    toast(`Reset done: ${o.deletedDelegates} delegate(s) and ${o.deletedObservers} observer(s) deleted. Backup: ${o.backup}`);
    load();
  } catch (err) { toast(err.message || 'Reset failed.', true); }
  btn.disabled = false;
});
$('#logout').addEventListener('click', async () => { try { await fetch('/api/admin/logout', { method: 'POST' }); } catch {} location.reload(); });
